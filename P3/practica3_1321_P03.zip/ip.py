'''
    ip.py
    
    Funciones necesarias para implementar el nivel IP
    
    Autor: Alejandro Raúl Hurtado <alejandror.hurtado@estudiante.uam.es>
    Autor: Camilo Jené Conde <camilo.jenec@estudiante.uam.es>
    2022 EPS-UAM
'''
from ethernet import *
from arp import *
from fcntl import ioctl
import subprocess

import struct

SIOCGIFMTU = 0x8921
SIOCGIFNETMASK = 0x891b
#Diccionario de protocolos. Las claves con los valores numéricos de protocolos de nivel superior a IP
#por ejemplo (1, 6 o 17) y los valores son los nombres de las funciones de callback a ejecutar.
protocols={}
#Tamaño mínimo de la cabecera IP
IP_MIN_HLEN = 20
#Tamaño máximo de la cabecera IP
IP_MAX_HLEN = 60

# Inicializamos el valor IPID al nº de pareja.
IPID = 3

# ETHERTYPE utilizado por defecto.
ETHERTYPE = 0x0800

def chksum(msg):
    '''
        Nombre: chksum
        Descripción: Esta función calcula el checksum IP sobre unos datos de entrada dados (msg)
        Argumentos:
            -msg: array de bytes con el contenido sobre el que se calculará el checksum
        Retorno: Entero de 16 bits con el resultado del checksum en ORDEN DE RED
    '''
    s = 0
    y = 0x07E6       
    for i in range(0, len(msg), 2):
        if (i+1) < len(msg):
            a = msg[i] 
            b = msg[i+1]
            s = s + (a+(b << 8))
        elif (i+1)==len(msg):
            s += msg[i]
        else:
            raise 'Error calculando el checksum'
    y = y & 0x00ff
    s = s + (s >> 16)
    s = ~s & 0xffff

    return s

def getMTU(interface):
    '''
        Nombre: getMTU
        Descripción: Esta función obteiene la MTU para un interfaz dada
        Argumentos:
            -interface: cadena con el nombre la interfaz sobre la que consultar la MTU
        Retorno: Entero con el valor de la MTU para la interfaz especificada
    '''
    s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
    ifr = struct.pack('16sH', interface.encode("utf-8"), 0)
    mtu = struct.unpack('16sH', ioctl(s,SIOCGIFMTU, ifr))[1]
   
    s.close()
   
    return mtu
   
def getNetmask(interface):
    '''
        Nombre: getNetmask
        Descripción: Esta función obteiene la máscara de red asignada a una interfaz 
        Argumentos:
            -interface: cadena con el nombre la interfaz sobre la que consultar la máscara
        Retorno: Entero de 32 bits con el valor de la máscara de red
    '''
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ip = fcntl.ioctl(
        s.fileno(),
       SIOCGIFNETMASK,
        struct.pack('256s', (interface[:15].encode('utf-8')))
    )[20:24]
    s.close()
    return struct.unpack('!I',ip)[0]


def getDefaultGW(interface):
    '''
        Nombre: getDefaultGW
        Descripción: Esta función obteiene el gateway por defecto para una interfaz dada
        Argumentos:
            -interface: cadena con el nombre la interfaz sobre la que consultar el gateway
        Retorno: Entero de 32 bits con la IP del gateway
    '''
    p = subprocess.Popen(['ip r | grep default | awk \'{print $3}\''], stdout=subprocess.PIPE, shell=True)
    dfw = p.stdout.read().decode('utf-8')
    print(dfw)
    return struct.unpack('!I',socket.inet_aton(dfw))[0]



def process_IP_datagram(us,header,data,srcMac):
    '''
        Nombre: process_IP_datagram
        Descripción: 
            Esta función procesa datagramas IP recibidos.
            Se ejecuta una vez por cada trama Ethernet recibida con Ethertype 0x0800
            Esta función debe realizar, al menos, las siguientes tareas:
                -Extraer los campos de la cabecera IP (includa la longitud de la cabecera)
                -Calcular el checksum y comprobar que es correcto                    
                -Analizar los bits de de MF y el offset. Si el offset tiene un valor != 0 dejar de procesar el datagrama (no vamos a reensamblar)
                -Loggear (usando logging.debug) el valor de los siguientes campos:
                    -Longitud de la cabecera IP
                    -IPID
                    -TTL
                    -Valor de las banderas DF y MF
                    -Valor de offset
                    -IP origen y destino
                    -Protocolo
                -Comprobar si tenemos registrada una función de callback de nivel superior consultando el diccionario protocols y usando como
                clave el valor del campo protocolo del datagrama IP.
                    -En caso de que haya una función de nivel superior registrada, debe llamarse a dicha función 
                    pasando los datos (payload) contenidos en el datagrama IP.
        
        Argumentos:
            -us: Datos de usuario pasados desde la llamada de pcap_loop. En nuestro caso será None
            -header: cabecera pcap_pktheader
            -data: array de bytes con el contenido del datagrama IP
            -srcMac: MAC origen de la trama Ethernet que se ha recibido
        Retorno: Ninguno
    '''
    # Diccionario con los protocolos utilizados en la práctica. key = número, valor = nombre del protocolo.
    dicc_protocolos = {1: "ICMP", 6: "TCP", 17: "UDP"}

    # Extreaemos los campos de la cabecera IP
    data = bytearray(data)

    version = data[0] >> 4

    IHL = (data[0] & 0x0F) * 4

    typeOfService = data[1]
    totalLength = data[2:4]
    ipID = data[4:6]

    # primer bit << reservado == 0 >> -DFMF- ----
    # DF y MF
    flags = data[6]
    DF = flags & 0x40 # Hacemos and y comprobamos el 7º bit con flags.
    DF = DF >> 6

    MF = flags & 0x20
    MF = MF >> 5

    offset = struct.unpack("!H", data[6:8])[0] & 0x1FFF
    offset = offset << 3

    timeToLive = data[8]
    protocol = data[9]; 
    if protocol not in dicc_protocolos:
        logging.debug("Error en el protocolo. No corresponde a ICMP, IP o UDP")

    hChksum = data[10:12] # Obtenemos el checksum y lo igualamos a 0.
    #aux = 0
    #data[10:12] = aux.to_bytes(2, "big")
    ipOrigen = data[12:16]
    ipDestino = data[16:20]

    # Para sacar las opciones, obtenemos el tamaño IHL.
    if IHL > IP_MIN_HLEN:
        opciones = data[20:IHL]

    suma_chksum = chksum(data[:IHL])
    if suma_chksum != 0:
        logging.debug("Cheksum != 0: no válido")
        #return
    
    if offset != 0:
        return

    logging.debug("Longitud de cabecera IP: " + str(IHL))
    logging.debug("IPID: " + str(ipID))
    logging.debug("TTL: " + str(timeToLive))
    logging.debug("DF flag: " + str(DF))
    logging.debug("MF flag: " + str(MF))
    logging.debug("Offset: " + str(offset))
    logging.debug("IP Origen: " + str(ipOrigen))
    logging.debug("IP Destino: " + str(ipDestino))
    logging.debug(f"Protocolo: {dicc_protocolos[protocol]}")

    if protocol in protocols:
        func = protocols[protocol]
        payload = data[IHL:]
        func(us, header, payload, ipOrigen)
    else:
        logging.debug("No se encuentra el protocolo en el diccionario de protocolos.")
        
    return


def registerIPProtocol(callback,protocol):
    '''
        Nombre: registerIPProtocol
        Descripción: Esta función recibirá el nombre de una función y su valor de protocolo IP asociado y añadirá en la tabla 
            (diccionario) de protocolos de nivel superior dicha asociación. 
            Este mecanismo nos permite saber a qué función de nivel superior debemos llamar al recibir un datagrama IP  con un 
            determinado valor del campo protocolo (por ejemplo TCP o UDP).
            Por ejemplo, podemos registrar una función llamada process_UDP_datagram asociada al valor de protocolo 17 y otra 
            llamada process_ICMP_message asocaida al valor de protocolo 1. 
        Argumentos:
            -callback_fun: función de callback a ejecutar cuando se reciba el protocolo especificado. 
                La función que se pase como argumento debe tener el siguiente prototipo: funcion(us,header,data,srcIp):
                Dónde:
                    -us: son los datos de usuarios pasados por pcap_loop (en nuestro caso este valor será siempre None)
                    -header: estructura pcap_pkthdr que contiene los campos len, caplen y ts.
                    -data: payload del datagrama IP. Es decir, la cabecera IP NUNCA se pasa hacia arriba.
                    -srcIP: dirección IP que ha enviado el datagrama actual.
                La función no retornará nada. Si un datagrama se quiere descartar basta con hacer un return sin valor y dejará de procesarse.
            -protocol: valor del campo protocolo de IP para el cuál se quiere registrar una función de callback.
        Retorno: Ninguno 
    '''
    protocols[protocol] = callback

def initIP(interface,opts=None):
    '''
        Nombre: initIP
        Descripción: Esta función inicializará el nivel IP. Esta función debe realizar, al menos, las siguientes tareas:
            -Llamar a initARP para inicializar el nivel ARP
            -Obtener (llamando a las funciones correspondientes) y almacenar en variables globales los siguientes datos:
                -IP propia
                -MTU
                -Máscara de red (netmask)
                -Gateway por defecto
            -Almacenar el valor de opts en la variable global ipOpts
            -Registrar a nivel Ethernet (llamando a registerCallback) la función process_IP_datagram con el Ethertype 0x0800
            -Inicializar el valor de IPID con el número de pareja
        Argumentos:
            -interface: cadena de texto con el nombre de la interfaz sobre la que inicializar ip
            -opts: array de bytes con las opciones a nivel IP a incluir en los datagramas o None si no hay opciones a añadir
        Retorno: True o False en función de si se ha inicializado el nivel o no
    '''
    global myIP, MTU, netmask, defaultGW,ipOpts

    if initARP(interface) == -1:
        return False

    # Almacenamos las variables globales.
    myIP = getIP(interface)
    MTU = getMTU(interface)
    netmask = getNetmask(interface)
    defaultGW = getDefaultGW(interface)
    ipOpts = opts

    registerCallback(process_IP_datagram, ETHERTYPE)

    return True


def sendIPDatagram(dstIP,data,protocol):
    '''
        Nombre: sendIPDatagram
        Descripción: Esta función construye un datagrama IP y lo envía. En caso de que los datos a enviar sean muy grandes la función
        debe generar y enviar el número de fragmentos IP que sean necesarios.
        Esta función debe realizar, al menos, las siguientes tareas:
            -Determinar si se debe fragmentar o no y calcular el número de fragmentos
            -Para cada datagrama o fragmento:
                -Construir la cabecera IP con los valores que corresponda.Incluir opciones en caso de que ipOpts sea distinto de None
                -Calcular el checksum sobre la cabecera y añadirlo a la cabecera
                -Añadir los datos a la cabecera IP
                -En el caso de que sea un fragmento ajustar los valores de los campos MF y offset de manera adecuada
                -Enviar el datagrama o fragmento llamando a sendEthernetFrame. Para determinar la dirección MAC de destino
                al enviar los datagramas se debe hacer unso de la máscara de red:                  
            -Para cada datagrama (no fragmento):
                -Incrementar la variable IPID en 1.
        Argumentos:
            -dstIP: entero de 32 bits con la IP destino del datagrama 
            -data: array de bytes con los datos a incluir como payload en el datagrama
            -protocol: valor numérico del campo IP protocolo que indica el protocolo de nivel superior de los datos
            contenidos en el payload. Por ejemplo 1, 6 o 17.
        Retorno: True o False en función de si se ha enviado el datagrama correctamente o no
          
    '''   
    global IPID, myIP, defaultGW, netmask, MTU

    ip_header = bytes()

    # Calculamos el tamaño de la cabecera.
    tamHeaderIP = IP_MIN_HLEN + len(ipOpts) if ipOpts is not None else IP_MIN_HLEN

    if tamHeaderIP > IP_MAX_HLEN:
        logging.debug("ERROR: el tamaño de la cabecera IP es demasiado grande.")
        return False
    
    # Fragmentación
    maxDatosUtiles = MTU - tamHeaderIP

    while maxDatosUtiles % 8 != 0: # Comprobamos que la cantidad máxima es múltiplo de 8.
        maxDatosUtiles -= 1

    # Calculamos el nº de fragmentos a enviar.    
    numFragmentos = len(data) / maxDatosUtiles if len(data) % maxDatosUtiles == 0 else len(data) // maxDatosUtiles + 1

    # Para cada fragmento realizamos el algoritmo.
    for fragmento in range(numFragmentos):
        ip_fragment = bytearray()

        version = 0x40 # En nuestro caso siempre es 4 (0100 ----)
        IHL = int(tamHeaderIP / 4)
        ip_fragment += (version + IHL).to_bytes(1, "big") # ip_fragment[0]

        typeOfService = 0x16
        ip_fragment += (typeOfService).to_bytes(1, "big") # ip_fragment[1]

        totalLength = len(data) - maxDatosUtiles * fragmento
        ip_fragment += (totalLength).to_bytes(2, "big") # ip_fragment[2:4]

        ip_fragment += (IPID).to_bytes(2, "big") # ip_fragment[4:6]

        # Aquí van los flags y el offset.
        # bitReservado = 0
        # DF = 0
        # MF = 0 si último fragmento else 1
        flags = 0x0000 if fragmento+1 == numFragmentos else 0x2000
        offset = int((maxDatosUtiles * fragmento) // 8)

        ip_fragment += (flags | offset).to_bytes(2, "big") # COMPROBAR BIEN ESTO


        timeToLive = 128
        ip_fragment += (timeToLive).to_bytes(1, "big") # ip_fragment[8]

        ip_fragment += (protocol).to_bytes(1, "big") # ip_fragment[9]

        checksum = 0
        ip_fragment += (checksum).to_bytes(2, "big") # ip_fragment[10:12]

        ip_fragment += (myIP).to_bytes(4, "big") # ip_fragment[12:16]

        if isinstance(dstIP, int):
            ip_fragment += (dstIP).to_bytes(4, "big")
        else:
            ip_fragment += dstIP 
            dstIP = int.from_bytes(dstIP, "big")
        
        if ipOpts is not None: ip_fragment += ipOpts

        # Una vez acabado, calculamos el checksum y lo introducimos en el fragmento.
        checksum = chksum(ip_fragment)

        ip_fragment[10:12] = checksum.to_bytes(2, "big")

        #Añadimos el fragmento ip al datagrama.
        ip_header = ip_fragment

        ip_header += data if numFragmentos == 1 else \
            data[fragmento * maxDatosUtiles : (fragmento + 1) * maxDatosUtiles]

        #Enviamos el datagraga con sendEthernetFrame
        MACDestino = ARPResolution(dstIP) if (myIP & netmask) == (dstIP & netmask) \
            else ARPResolution(defaultGW)

        if MACDestino is None:
            return False

        if sendEthernetFrame(ip_header, len(ip_header), ETHERTYPE, MACDestino) == -1:
            logging.debug(f"ERROR: sendEthernetFrame() en el fragmento: {fragmento} <<< ")
            return False

    IPID += 1

    return True
    """
        FRASE PUESTA PARA CUANDO SE DEDICA MI ORDENADOR A BORRAR LA PARTE DEL FINAL 
    """